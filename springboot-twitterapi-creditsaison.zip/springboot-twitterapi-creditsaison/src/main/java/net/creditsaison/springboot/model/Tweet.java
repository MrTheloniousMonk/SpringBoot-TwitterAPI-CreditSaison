package net.creditsaison.springboot.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

//import javax.persistence.Column;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Date;

@Data
@NoArgsConstructor
@Document(collection = "tweet_table")
public class Tweet {

    @Id
    private String id;
    
    //@Column(name = "username")
    private String username;
    
	@NotBlank
    @Size(min = 2, max = 140, message ="Tweet should have minimun 2 characters and mazimum 140 characters")
    private String text;
	
	 @NotNull
	    private Date createdDate = new Date ();
	 
	 

    public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}

   
    

    public Tweet(String text) {
    	
        this.id = id;
        this.text = text;
    }
    
    
	public Date getCreatedDate() {
		return createdDate;
	}


	

	public void setId(String id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}


	public String getId() {
		
		return id;
	}
	
	

}