package net.creditsaison.springboot.model;



import java.util.Date;

//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Document(collection = "user_table")
public class User {
	
	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@NotEmpty
	@Size(min = 8, max = 10, message = "username should have at least 8 characters and maximun of 10  characters")
	private String username;
	
	@NotNull
    private Date createdDate = new Date ();
	
	public Date getCreatedDate() {
		return createdDate;
	}

	public int getId() {
		return id;
	}

	public String getUsername() {
		return username;
	}

	
	
	

}
