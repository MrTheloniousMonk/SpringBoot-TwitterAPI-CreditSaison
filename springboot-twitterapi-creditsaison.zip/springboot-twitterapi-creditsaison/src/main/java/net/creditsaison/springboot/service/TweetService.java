package net.creditsaison.springboot.service;

import net.creditsaison.springboot.model.Tweet;
import net.creditsaison.springboot.repository.TweetRepository;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TweetService {
	
	private List<Tweet> tweets = new ArrayList<>();
			
	@Autowired
	private TweetRepository tweetRepository;
	
	public boolean checkTweetSize(String text) {
		
		if(text.length() >=2 && text.length() <= 140)
			return true;
		else
			return false;
		
	}
	
	public boolean checkUsername(String username) {
		
		for( Tweet t : tweets) {
			if(t.getUsername().equals(username))
				return false;
			
		}
		return true;
		
	}
	
	public Tweet saveTweet(Tweet tweet) {
			 return tweetRepository.save(tweet);
		
	}

	
	//Get all tweets from a User
	public List<Tweet> getTweetsFromUser(String username){
		List<Tweet> userTweets = new ArrayList<>();
		for(Tweet t : tweets) {
			if(t.getUsername() == username) {
				userTweets.add(t);
			}
				
		}
		return userTweets;
		
	}
	
	
	//Delete all Tweets from a User
	
	public List<Tweet> deleteTweetsFromUser(String username){
		List<Tweet> deletedTweets = new ArrayList<>();
		for(Tweet t : tweets) {
			if(t.getUsername() == username) {
				deletedTweets.add(t);
			}
			tweetRepository.delete(t);
		}
		return deletedTweets;
	}

	
}