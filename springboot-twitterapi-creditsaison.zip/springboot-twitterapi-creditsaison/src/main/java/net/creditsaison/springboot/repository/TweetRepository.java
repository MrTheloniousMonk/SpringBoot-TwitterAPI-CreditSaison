package net.creditsaison.springboot.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import net.creditsaison.springboot.model.Tweet;

public interface TweetRepository extends MongoRepository<Tweet, String> {
}