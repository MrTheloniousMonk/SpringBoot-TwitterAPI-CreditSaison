package net.creditsaison.springboot.controller;
/**
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import net.creditsaison.springboot.model.Tweet;
import net.creditsaison.springboot.service.TweetService;
import net.creditsaison.springboot.repository.TweetRepository;
*/

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import net.creditsaison.springboot.model.Tweet;
import net.creditsaison.springboot.repository.TweetRepository;
import net.creditsaison.springboot.service.TweetService;

@RestController
public class TweetController{
	
	@Autowired
	private TweetRepository tweetRepository;
	
	@Autowired
	private TweetService tweetService;
	
	
	//Create_User_API
	@PostMapping("/addTweet")
	public String createTweet(Tweet tweet) {
		
		String tweetText = tweet.getText();
		String username = tweet.getUsername();
		
		if(tweetService.checkTweetSize(tweetText) == true && tweetService.checkUsername(username))
		{
		
			this.tweetService.saveTweet(tweet);
			return "Added tweet with id : "+tweet.getId()+tweet.getCreatedDate();
		}
		else
			return "Size of the tweet is does not fit the criteria";
	}




	@GetMapping("/findTweets/{username}")
	public List<Tweet> getUserTweets(@PathVariable String username){
		return this.tweetService.getTweetsFromUser(username);
		
	}
	
	@DeleteMapping("/deleteTweet/{id}")
	public String deleteTweet(@PathVariable String id) {
		
		List<Tweet> deletedTweets= new ArrayList<>();
		deletedTweets = tweetService.deleteTweetsFromUser(id);
		for(Tweet t : deletedTweets) {
			System.out.println(t.getText());
		}
		System.out.println("Total Number of Deleted Tweets = "+ deletedTweets.size());
		return "";
		
	}
	
	
	
	
}


/**
@RestController
public class TweetController{
	
	@Autowired
	private TweetRepository tweetRepository;
	
	
	@Autowired
	private TweetService tweetService;
	
	//Create_tweets
	@PostMapping("/tweets")
	public Tweet create_tweet(@RequestBody Tweet tweet) {
		Tweet t = this.tweetService.create_tweet(tweet);
		System.out.print("Tweet id is = "+ t.getId());
		System.out.print("Tweet timestamp is = "+t.getCreatedDate());
		return t;
	}
	
	
	//Get Tweets By Username From a Specific Date
	@SuppressWarnings("unchecked")
	@GetMapping("/tweets/{username}/{date}")
	public List<Tweet> getTweets(@PathVariable("username") String username) {
		return (List<Tweet>)tweetService.getTweetsFromUsername(username);
	}

	
	@DeleteMapping("/deleteTweet/{id}")
	public String deleteTweet(@PathVariable String id) {
		
		tweetRepository.deleteById(id);
		
	}

	}

*/
	
