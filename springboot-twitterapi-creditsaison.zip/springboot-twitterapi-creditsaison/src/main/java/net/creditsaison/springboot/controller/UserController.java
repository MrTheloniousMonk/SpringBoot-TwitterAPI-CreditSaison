package net.creditsaison.springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import net.creditsaison.springboot.model.User;
import net.creditsaison.springboot.repository.UserRepository;

@RestController
public class UserController {

	@Autowired
	private UserRepository userRepository;
	
	@PostMapping("/create_user")
	//Creating a user
	public void saveUser(@RequestBody User user) {
		
		//Assining the username to  variable username
		String username = user.getUsername();
		
		//Check if the username is a valid username
		if(checkUsernameLength(username) == true) {
		//if valid then saving the username in the repository
		userRepository.save(user);
		System.out.println( "User created with id : "+user.getId()+user.getCreatedDate());
	
	}
}
	
	//Check to see if username is valid
	public boolean checkUsernameLength(String username) {
		if(username.length() >= 8 && username.length() <= 10)
			return true;
		else
			return false;
	}
}
